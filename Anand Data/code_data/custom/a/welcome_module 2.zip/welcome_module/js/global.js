(function ($, Drupal, drupalSettings) {

  'use strict';

  Drupal.behaviors.drupalhacksGlobal = {
    attach: function (context, settings) {

      // $('a').css('color', 'red');
      // alert(settings.abc);

       var translatedString = Drupal.t('a string about @subject that needs to be translated', {'@subject': 'Javascript in Drupal'});
      //alert(translatedString);

    }
  };

})(jQuery, Drupal, drupalSettings);
