(function ($, Drupal, drupalSettings) {
  Drupal.behaviors.mycustomblock = {
    attach: function (context) {
     // var data = drupalSettings.test;
      //alert(data);
      /*var translatedString = Drupal.t('a string about @subject that needs to be translated', {'@subject': 'Javascript in Drupal'});
      alert(translatedString);*/

      typeVar ='product';

      var plural = Drupal.formatPlural(1, 'I have 1 item', 'I have @count @type items', {'@type': typeVar});
	  //alert(plural);
    }
  };
})(jQuery, Drupal, drupalSettings);
