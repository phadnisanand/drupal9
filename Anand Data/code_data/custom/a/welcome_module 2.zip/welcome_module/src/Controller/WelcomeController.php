<?php

namespace Drupal\welcome_module\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Config\ConfigFactory;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\welcome_module\CustomService;
use Drupal\Core\Language\LanguageManager;
use Drupal\Core\Path\CurrentPathStack;
use Drupal\Core\Routing\CurrentRouteMatch;
use Symfony\Component\HttpFoundation\Request;
use Drupal\Core\Render\Markup;
use Drupal\Core\Render\MainContent\HtmlRenderer;
use Drupal\Core\Render;
use Drupal\user\Entity\User;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\node\Entity\Node;
use Drupal\Core\Session\AccountInterface;
use Drupal\node\NodeInterface;
use Drupal\welcome_module\ParamConverter\NodesConverter;
/**
 * Defines WelcomeController class.
 */
class WelcomeController extends ControllerBase {
   protected $configFactory;

   public static function create(ContainerInterface $container) {
    return new static($container->get('config.factory'), $container->get('welcome_module.custom_services'),$container->get('language_manager'),
      $container->get('current_route_match'), $container->get('path.current'));
  }

  public function __construct(ConfigFactory $config_factory, CustomService $custom_service,LanguageManager $language,CurrentRouteMatch $route,CurrentPathStack $currentPath) {
    $this->configFactory  =  $config_factory;
    $this->custom_service = $custom_service;
    $this->language = $language;
    $this->route = $route;
    $this->currentPath =$currentPath;
  }

  public function nodedata(NodeInterface $node) { //die('coming');
       $element = array(
      '#markup' => $node->body->value,
    );
    return $element;

  }

  public function nodesdata() { //die('coming');

     $arr= $this->route->getParameters('nodes');
     $param= NodesConverter::convert($arr);

     print_r($param); exit;
    $element = array(
      '#markup' => $node->body->value,
    );
    return $element;

  }
  public function homePage() {
    $user = $this->route->getParameter('user');
    if ($user instanceof AccountInterface) {
    // echo $user->id();  die('coming 1');
      $user = \Drupal::entityTypeManager()->getStorage('user')->load($user->id());

      echo  $user->getDisplayName(); exit;
    }
    elseif (!empty($user)) {
      $user = \Drupal::entityTypeManager()->getStorage('user')->load($user);
      if($user instanceof AccountInterface) {
       //$user = \Drupal::entityTypeManager()->getStorage('user')->load($user);

      echo  $user->getDisplayName(); exit;
      }
    }

    echo 'hi'; die('coming 3');


    //$node = \Drupal::routeMatch()->getParameter('user');
    //print_r( $node); exit;
    //if ($node instanceof \Drupal\node\NodeInterface) { die('coming');
      // $node_details = Node::load($node);
       //print_r( $node_details->title->value); exit;
    //}
    //print_r( $user); exit;

  }



  public function multiply() {
    $request = \Drupal::request();
    $output['a'] = $request->get('a');
    $output['b'] = $request->get('b');
    $output['result'] = $output['a'] * $output['b'];
    return new JsonResponse($output);
  }


  /**
   * Display the markup.
   *
   * @return array
   *   Return markup array.
   */
  public function content() {

    return array(
        '#markup' => rand(10,100),
        '#cache' => [
            'tags' => ['MY_CUSTOM_UNIQUE_TAG'],
        ],
    );
    //die('hi');

 /*$default_entity = $this->entityTypeManager()->getStorage('default_entity');


$entities = \Drupal::entityQuery('default_entity')
  ->condition('status', 1)
  ->execute();*/

/*$result = \Drupal::entityQuery('default_entity')
      ->condition('type', 'products')
      ->execute();*/
//print_r($result ); exit;


 /*$node_storage = \Drupal::entityTypeManager()->getStorage('default_entity')->loadMultiple($result);
foreach ($node_storage as $node){
   $field_price = $node->get('field_price')->value;
   $field_name = $node->get('field_name')->value;


   echo $field_name . '  ' . $field_price;

    echo '<br />';

}
exit;
*/
      
  

  //$node_storage = \Drupal::entityManager()->getStorage('default_entity');

// Load multiple nodes
//$node_storage->loadMultiple();
//$nodes = entity_load('default_entity', array_keys($entities['node']));



 

   /*$storage = \Drupal::entityTypeManager()->getStorage('default_entity');
 

   $node = $storage->load(2);


  print_r($node->field_name->value);

  exit;*/

    /*$nid= 1;
    $arr= array(
            '#theme' => 'mymodule_controller_template',
            '#myvariable' => $nid,
            '#attached' => [
              'library' => [
                'welcome_module/global-add',
              ],
            ],
        );
    $theme = \Drupal::service('renderer')->render($arr);
    return [
        '#type' => 'markup',
        '#markup' => $theme ,
      ];*/


    /*$name =  $this->route->getRawParameter('name'); 

    return array(
      '#type' => 'markup',
      '#markup' => t('Welcome to site @name', array('@name' => $name)),
    );*/



   /* $count = 1;
    $message_two = \Drupal::translation()->formatPlural($count, "$count node was updated.", "$count nodes were updated.");


    return array(
      '#type' => 'markup',
      '#markup' => $message_two,
    );*/
    /*$name =  $this->route->getRawParameter('name'); 
    //echo $name;exit;
    $count = 4;
    $message = \Drupal::translation()->formatPlural($count, "%name node was updated $count time.", "%name nodes were updated $count times.",array('%name' => $name));

    return array(
      '#type' => 'markup',
      '#markup' => $message,
    );*/

   
    /*return [
              '#type' => 'progress_bar',
              '#value' => 80,
              '#max' => 100
           ];*/


 //die('hi');
//$data= [10,20,30];
//return new JsonResponse($data);
    /*$nid= 1;
    $arr= array(
            '#theme' => 'mymodule_controller_template',
            '#myvariable' => $nid,
            '#attached' => [
              'library' => [
                'welcome_module/global',
              ],
            ],
        );
    $theme = \Drupal::service('renderer')->render($arr);
    return [
        '#type' => 'markup',
        '#markup' => $theme ,
      ];*/


    /*$username = ['#theme' => 'username', '#account' => User::load(1)];
    //echo $username; exit;
    $author = \Drupal::service('renderer')->render($username);
    return [
        '#type' => 'markup',
        '#markup' => 'Hi ' . $author  ,
      ];
*/

   /* $rows = [
      [Markup::create('<strong>test 1</strong>'),'test'],
      [Markup::create('<s>test 2</s>'), 'test'],
      [Markup::create('<div>test 3</div>'), 'test'],
    ];

    $header = [
      'title' => t('Title'),
     'content' => t('Content'),
    ];
    $build['table'] = [
      '#type' => 'table',
      '#header' => $header,
      '#rows' => $rows,
      '#empty' => t('No content has been found.'),
    ];

    $table = array(
     '#type' => 'table',
     '#header' => $header,
    '#rows' => $rows,
     '#attributes' => array(
      'id' => 'my-module-table',
    ),
  );
     $output = \Drupal::service('renderer')->render($build);
     //echo $output; exit;
     return [
        '#type' => 'markup',
        '#markup' => $output  ,
      ];*/



    // return $output; 

  //$str= '<p>Html renderer</p>';


    //return Drupal::service('renderer')->renderRoot($build);


    /*return [
      '#type' => 'container',
      'heading' => [
        '#type' => 'html_tag',
        '#tag' => 'h1',
        '#value' => 'Nested arrays',
      ],
      'content' => [
        [
          '#type' => 'html_tag',
          '#tag' => 'p',
          '#value' => 'Array keys starting with # are treated as render element properties.',
        ],
        [
          '#type' => 'html_tag',
          '#tag' => 'p',
          '#value' => 'All the other keys become children.',
        ],
      ],
    ];*/

  
    
    //die('come');
   //return \Drupal::service('renderer')->renderPlain($build);
  /*return [
    '#type' => 'html',
    '#markup' => $str
  ];*/

    /*$build= array(10,20,30);

    $output = \Drupal::service('renderer')->render($build);

    return $output;*/

    //\Drupal::state()->delete('first_name');
    //\Drupal::state()->delete('last_name');
   // echo \Drupal::state()->get('first_name') . '  '. \Drupal::state()->get('last_name');
    /*$keyvalues= array('first_name', 'last_name');
   $arr= \Drupal::state()->getMultiple($keyvalues);
   print_r($arr);
    exit;*/
  //$request = Request::createFromGlobals();
//print_r($request->query->get('foo'); exit;

    //echo  $this->route->getRawParameter('name'); 

    //echo $this->route->getRouteName(); exit;

    /*exit; 
  $current_path = \Drupal::service('path.current')->getPath();
$url_object = \Drupal::service('path.validator')->getUrlIfValid($current_path);
$route_name = $url_object->getRouteName();
$route_parameters = $url_object->getrouteParameters();
print_r($route_parameters); exit;
*/

  /* return array(
      '#type' => 'markup',
      '#markup' => t('Hello @name', array('@name' => $name)),
    );

   render
*/


 /*   $nid= 1;
  return array(
          '#theme' => 'mymodule_controller_template',
          '#myvariable' => $nid,
          '#attached' => [
            'library' => [
              'welcome_module/global',
            ],
          ],
      );*/


   $data = $this->custom_service->getData();

   return [
      '#type' => 'markup',
      '#markup' =>  $data ,
    ];

    //print_r($data);exit;

    /*$current_path = $this->currentPath->getPath();
    echo $current_path;
    die();*/
    /*$config = $this->configFactory->getEditable('welcome_module.settings');
    $first_name= $config->get('first_name');
    $last_name = $config->get('last_name');
    */
    /*$nid = 1;     // example value
    $node_storage = \Drupal::entityTypeManager()->getStorage('node');
    $node = $node_storage->load($nid);
    echo $node->title->value;  
     exit;*/
    /*return [
      '#type' => 'markup',
      '#markup' => 'Hi ' . $first_name . ' ' . $last_name . '  ' . 'new ' . $data ,
    ];*/
//echo '<pre>'; print_r($data[0][0]); exit;


    //echo render($arr);  exit;

  }

}