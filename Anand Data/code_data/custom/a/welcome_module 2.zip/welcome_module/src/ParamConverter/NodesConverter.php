<?php

namespace Drupal\welcome_module\ParamConverter;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Symfony\Component\Routing\Route;
use Drupal\Core\ParamConverter\ParamConverterInterface;

class NodesConverter implements ParamConverterInterface {

  protected $entityTypeManager;

  public function __construct(EntityTypeManagerInterface $entity_type_manager) {
    $this->entityTypeManager = $entity_type_manager;
  }

  public function convert($value, $definition, $name, array $defaults) { //die('coming');
    // Add whatever extra validation you feel is necessary here
    $nids = explode(',', $value);
//echo '<pre>'; print_r($nids); exit;
//$nids= array(1,2,3);
    if (!empty($nids)) {
      return $this->entityTypeManager->getStorage('node')
       ->loadMultiple($nids);
        //print_r($data); exit;
    }
  }

  public function applies($definition, $name, Route $route) {
    return !empty($definition['type']) && $definition['type'] == 'nodes';
  }

}