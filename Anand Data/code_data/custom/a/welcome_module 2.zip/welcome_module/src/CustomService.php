<?php

namespace Drupal\welcome_module;

use Drupal\Core\Session\AccountInterface;
use Drupal\Component\Serialization\Json;
use Drupal\Core\Http\ClientFactory;
use Drupal\Core\Language\LanguageManager;
use Drupal\Core\Routing\CurrentRouteMatch;
use Drupal\Core\Path\CurrentPathStack;
use Drupal\Core\Path\PathValidator;
use Drupal\Core\Entity\EntityTypeManager;
use Symfony\Component\DomCrawler\Crawler;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RequestStack;

/**
 * Class CustomService
 * @package Drupal\welcome_module\Services
 */
class CustomService {

  protected $currentUser;

  /**
   * CustomService constructor.
   * @param AccountInterface $currentUser
   */
  public function __construct(AccountInterface $currentUser,ClientFactory $http_client_factory,LanguageManager $language,
    CurrentRouteMatch $route, CurrentPathStack $currentPath,PathValidator $path,EntityTypeManager $entity_manager,RequestStack $requestStack) {
    $this->currentUser = $currentUser;
    $this->http_client_factory = $http_client_factory;
    $this->language = $language;
    $this->route  = $route;
    $this->currentPath = $currentPath;
    $this->path = $path;
    $this->entity_manager = $entity_manager;
    $this->requestStack = $requestStack;
  }


  /**
   * @return \Drupal\Component\Render\MarkupInterface|string
   */
  public function getData() { //die('coming');

    return $this->currentUser->getDisplayName();

    /*$node_storage = $this->entity_manager->getStorage('node');
    $node = $node_storage->load(1);
    echo $node->title->value;  
    exit;*/
    /*$client = $this->http_client_factory->fromOptions([
      'base_uri' => 'https://jsonplaceholder.typicode.com/',
    ]);

    $response = $client->get('posts', [
      'query' => [
        'amount' => 2,
      ]
    ]);

    $json_data = Json::decode($response->getBody());
   
    $items = [];

    foreach ($json_data as $json) {
      $items[] = $json_data;
    }*/

    

    //$content = $this->requestStack->getCurrentRequest();
    //print_r($content);
    //exit;

    /*$var = [
    'a simple string' => "in an array of 5 elements",
    'a float' => 1.0,
    'an integer' => 1,
    'a boolean' => true,
    'an empty array' => [],
];

$serializer = \Drupal::service('serialization.json');
  $encoded= Json::encode($var);

  $decoded=  Json::decode($encoded);

  print_r($decoded);
exit;*/
  
/*


dump($var);

exit;*/
 

/*$client = new Client();
$people = [];

try {
  $response = $client->get('https://swapi.dev/api/people');
  $result = json_decode($response->getBody(), TRUE);
  foreach($result['results'] as $item) {
    $people[] = $item['name']; 
  }
}
catch (RequestException $e) {
  // log exception
}

print_r( $people);
exit;*/

/*$html = <<<'HTML'
<!DOCTYPE html>
<html>
    <body>
        <p class="message">Hello World!</p>
        <p>Hello Crawler!</p>
        <div id="product">
            <a data-type="bla">
                <img src="OK">
            </a>
        </div>
    </body>
</html>
HTML;

$crawler = new Crawler($html);

$link = $crawler->filter('#product a[data-type="bla"]');

echo var_dump(count($link));

var_dump($link->filter('img')->attr('src'));
exit;*/
    /*$current_path = $this->currentPath->getPath();
    $url_object= $this->path->getUrlIfValid($current_path);
    $route_parameters = $url_object->getrouteParameters();

    print_r($current_path);*/
     //$default_language= 'en';
    /*$language_list =$this->language->getStandardLanguageList();
    print_r($language_list);
    exit;*/

    //return $items;
  }
}