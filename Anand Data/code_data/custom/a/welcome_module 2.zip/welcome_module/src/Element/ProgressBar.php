<?php

namespace Drupal\welcome_module\Element;

use Drupal\Core\Render\Element\RenderElement;
/**
 * Provides a render element for the title of an HTML page.
 *
 * This represents the title of the HTML page's body.
 *
 * @RenderElement("progress_bar")
 */
class ProgressBar extends RenderElement {

  /**
   * {@inheritdoc}
   */
  public function getInfo() { 
    return [
      '#theme' => 'progress_bar',
      '#value' => NULL,
      '#max' => NULL
    ];
  }

}
