<?php

namespace Drupal\welcome_module\Entity;

use Drupal\Core\Config\Entity\ConfigEntityInterface;

/**
 * Provides an interface for defining New type entities.
 */
interface newTypeInterface extends ConfigEntityInterface {

  // Add get/set methods for your configuration properties here.
}
