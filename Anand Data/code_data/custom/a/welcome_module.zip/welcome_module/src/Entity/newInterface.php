<?php

namespace Drupal\welcome_module\Entity;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\RevisionLogInterface;
use Drupal\Core\Entity\EntityChangedInterface;
use Drupal\Core\Entity\EntityPublishedInterface;
use Drupal\user\EntityOwnerInterface;

/**
 * Provides an interface for defining New entities.
 *
 * @ingroup welcome_module
 */
interface newInterface extends ContentEntityInterface, RevisionLogInterface, EntityChangedInterface, EntityPublishedInterface, EntityOwnerInterface {

  /**
   * Add get/set methods for your configuration properties here.
   */

  /**
   * Gets the New name.
   *
   * @return string
   *   Name of the New.
   */
  public function getName();

  /**
   * Sets the New name.
   *
   * @param string $name
   *   The New name.
   *
   * @return \Drupal\welcome_module\Entity\newInterface
   *   The called New entity.
   */
  public function setName($name);

  /**
   * Gets the New creation timestamp.
   *
   * @return int
   *   Creation timestamp of the New.
   */
  public function getCreatedTime();

  /**
   * Sets the New creation timestamp.
   *
   * @param int $timestamp
   *   The New creation timestamp.
   *
   * @return \Drupal\welcome_module\Entity\newInterface
   *   The called New entity.
   */
  public function setCreatedTime($timestamp);

  /**
   * Gets the New revision creation timestamp.
   *
   * @return int
   *   The UNIX timestamp of when this revision was created.
   */
  public function getRevisionCreationTime();

  /**
   * Sets the New revision creation timestamp.
   *
   * @param int $timestamp
   *   The UNIX timestamp of when this revision was created.
   *
   * @return \Drupal\welcome_module\Entity\newInterface
   *   The called New entity.
   */
  public function setRevisionCreationTime($timestamp);

  /**
   * Gets the New revision author.
   *
   * @return \Drupal\user\UserInterface
   *   The user entity for the revision author.
   */
  public function getRevisionUser();

  /**
   * Sets the New revision author.
   *
   * @param int $uid
   *   The user ID of the revision author.
   *
   * @return \Drupal\welcome_module\Entity\newInterface
   *   The called New entity.
   */
  public function setRevisionUserId($uid);

}
