<?php

namespace Drupal\welcome_module\Entity;

use Drupal\Core\Config\Entity\ConfigEntityBundleBase;

/**
 * Defines the New type entity.
 *
 * @ConfigEntityType(
 *   id = "new_type",
 *   label = @Translation("New type"),
 *   handlers = {
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "list_builder" = "Drupal\welcome_module\newTypeListBuilder",
 *     "form" = {
 *       "add" = "Drupal\welcome_module\Form\newTypeForm",
 *       "edit" = "Drupal\welcome_module\Form\newTypeForm",
 *       "delete" = "Drupal\welcome_module\Form\newTypeDeleteForm"
 *     },
 *     "route_provider" = {
 *       "html" = "Drupal\welcome_module\newTypeHtmlRouteProvider",
 *     },
 *   },
 *   config_export = {
 *     "id",
 *     "label"
 *   },
 *   config_prefix = "new_type",
 *   admin_permission = "administer site configuration",
 *   bundle_of = "new",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label",
 *     "uuid" = "uuid"
 *   },
 *   links = {
 *     "canonical" = "/yes/new_type/{new_type}",
 *     "add-form" = "/yes/new_type/add",
 *     "edit-form" = "/yes/new_type/{new_type}/edit",
 *     "delete-form" = "/yes/new_type/{new_type}/delete",
 *     "collection" = "/yes/new_type"
 *   }
 * )
 */
class newType extends ConfigEntityBundleBase implements newTypeInterface {

  /**
   * The New type ID.
   *
   * @var string
   */
  protected $id;

  /**
   * The New type label.
   *
   * @var string
   */
  protected $label;

}
