<?php

namespace Drupal\welcome_module;

use Drupal\content_translation\ContentTranslationHandler;

/**
 * Defines the translation handler for blog.
 */
class blogTranslationHandler extends ContentTranslationHandler {

  // Override here the needed methods from ContentTranslationHandler.
}
