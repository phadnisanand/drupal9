<?php

namespace Drupal\welcome_module\Controller;

use Drupal\Component\Utility\Xss;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\Core\Link;
use Drupal\Core\Url;
use Drupal\welcome_module\Entity\newInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class newController.
 *
 *  Returns responses for New routes.
 */
class newController extends ControllerBase implements ContainerInjectionInterface {

  /**
   * The date formatter.
   *
   * @var \Drupal\Core\Datetime\DateFormatter
   */
  protected $dateFormatter;

  /**
   * The renderer.
   *
   * @var \Drupal\Core\Render\Renderer
   */
  protected $renderer;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    $instance = parent::create($container);
    $instance->dateFormatter = $container->get('date.formatter');
    $instance->renderer = $container->get('renderer');
    return $instance;
  }

  /**
   * Displays a New revision.
   *
   * @param int $new_revision
   *   The New revision ID.
   *
   * @return array
   *   An array suitable for drupal_render().
   */
  public function revisionShow($new_revision) {
    $new = $this->entityTypeManager()->getStorage('new')
      ->loadRevision($new_revision);
    $view_builder = $this->entityTypeManager()->getViewBuilder('new');

    return $view_builder->view($new);
  }

  /**
   * Page title callback for a New revision.
   *
   * @param int $new_revision
   *   The New revision ID.
   *
   * @return string
   *   The page title.
   */
  public function revisionPageTitle($new_revision) {
    $new = $this->entityTypeManager()->getStorage('new')
      ->loadRevision($new_revision);
    return $this->t('Revision of %title from %date', [
      '%title' => $new->label(),
      '%date' => $this->dateFormatter->format($new->getRevisionCreationTime()),
    ]);
  }

  /**
   * Generates an overview table of older revisions of a New.
   *
   * @param \Drupal\welcome_module\Entity\newInterface $new
   *   A New object.
   *
   * @return array
   *   An array as expected by drupal_render().
   */
  public function revisionOverview(newInterface $new) {
    $account = $this->currentUser();
    $new_storage = $this->entityTypeManager()->getStorage('new');

    $langcode = $new->language()->getId();
    $langname = $new->language()->getName();
    $languages = $new->getTranslationLanguages();
    $has_translations = (count($languages) > 1);
    $build['#title'] = $has_translations ? $this->t('@langname revisions for %title', ['@langname' => $langname, '%title' => $new->label()]) : $this->t('Revisions for %title', ['%title' => $new->label()]);

    $header = [$this->t('Revision'), $this->t('Operations')];
    $revert_permission = (($account->hasPermission("revert all new revisions") || $account->hasPermission('administer new entities')));
    $delete_permission = (($account->hasPermission("delete all new revisions") || $account->hasPermission('administer new entities')));

    $rows = [];

    $vids = $new_storage->revisionIds($new);

    $latest_revision = TRUE;

    foreach (array_reverse($vids) as $vid) {
      /** @var \Drupal\welcome_module\Entity\newInterface $revision */
      $revision = $new_storage->loadRevision($vid);
      // Only show revisions that are affected by the language that is being
      // displayed.
      if ($revision->hasTranslation($langcode) && $revision->getTranslation($langcode)->isRevisionTranslationAffected()) {
        $username = [
          '#theme' => 'username',
          '#account' => $revision->getRevisionUser(),
        ];

        // Use revision link to link to revisions that are not active.
        $date = $this->dateFormatter->format($revision->getRevisionCreationTime(), 'short');
        if ($vid != $new->getRevisionId()) {
          $link = Link::fromTextAndUrl($date, new Url('entity.new.revision', [
            'new' => $new->id(),
            'new_revision' => $vid,
          ]))->toString();
        }
        else {
          $link = $new->toLink($date)->toString();
        }

        $row = [];
        $column = [
          'data' => [
            '#type' => 'inline_template',
            '#template' => '{% trans %}{{ date }} by {{ username }}{% endtrans %}{% if message %}<p class="revision-log">{{ message }}</p>{% endif %}',
            '#context' => [
              'date' => $link,
              'username' => $this->renderer->renderPlain($username),
              'message' => [
                '#markup' => $revision->getRevisionLogMessage(),
                '#allowed_tags' => Xss::getHtmlTagList(),
              ],
            ],
          ],
        ];
        $row[] = $column;

        if ($latest_revision) {
          $row[] = [
            'data' => [
              '#prefix' => '<em>',
              '#markup' => $this->t('Current revision'),
              '#suffix' => '</em>',
            ],
          ];
          foreach ($row as &$current) {
            $current['class'] = ['revision-current'];
          }
          $latest_revision = FALSE;
        }
        else {
          $links = [];
          if ($revert_permission) {
            $links['revert'] = [
              'title' => $this->t('Revert'),
              'url' => $has_translations ?
              Url::fromRoute('entity.new.translation_revert', [
                'new' => $new->id(),
                'new_revision' => $vid,
                'langcode' => $langcode,
              ]) :
              Url::fromRoute('entity.new.revision_revert', [
                'new' => $new->id(),
                'new_revision' => $vid,
              ]),
            ];
          }

          if ($delete_permission) {
            $links['delete'] = [
              'title' => $this->t('Delete'),
              'url' => Url::fromRoute('entity.new.revision_delete', [
                'new' => $new->id(),
                'new_revision' => $vid,
              ]),
            ];
          }

          $row[] = [
            'data' => [
              '#type' => 'operations',
              '#links' => $links,
            ],
          ];
        }

        $rows[] = $row;
      }
    }

    $build['new_revisions_table'] = [
      '#theme' => 'table',
      '#rows' => $rows,
      '#header' => $header,
    ];

    return $build;
  }

}
