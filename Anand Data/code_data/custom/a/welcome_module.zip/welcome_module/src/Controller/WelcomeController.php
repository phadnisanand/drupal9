<?php

namespace Drupal\welcome_module\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Config\ConfigFactory;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\welcome_module\CustomService;
/**
 * Defines WelcomeController class.
 */
class WelcomeController extends ControllerBase {
   protected $configFactory;

   public static function create(ContainerInterface $container) {
    return new static($container->get('config.factory'), $container->get('welcome_module.custom_services'));
  }

  public function __construct(ConfigFactory $config_factory, CustomService $custom_service) {
    $this->configFactory  =  $config_factory;
    $this->custom_service = $custom_service;
  }
  /**
   * Display the markup.
   *
   * @return array
   *   Return markup array.
   */
  public function content() {
    $config = $this->configFactory->getEditable('welcome_module.settings');
    $first_name= $config->get('first_name');
    $last_name = $config->get('last_name');
    //$data = $this->custom_service->getData();
    
    /*return [
      '#type' => 'markup',
      '#markup' => 'Hi ' . $first_name . ' ' . $last_name . '  ' . 'new ' . $data ,
    ];*/


    return array(
            '#theme' => 'mymodule_controller_template',
            '#first_name' => $first_name,
            '#last_name'  => $last_name
        );

  }

}