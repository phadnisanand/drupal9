<?php

namespace Drupal\welcome_module;

use Drupal\content_translation\ContentTranslationHandler;

/**
 * Defines the translation handler for new.
 */
class newTranslationHandler extends ContentTranslationHandler {

  // Override here the needed methods from ContentTranslationHandler.
}
