<?php

namespace Drupal\welcome_module\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting New entities.
 *
 * @ingroup welcome_module
 */
class newDeleteForm extends ContentEntityDeleteForm {


}
