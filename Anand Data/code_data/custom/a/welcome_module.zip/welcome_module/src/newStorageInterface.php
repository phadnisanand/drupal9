<?php

namespace Drupal\welcome_module;

use Drupal\Core\Entity\ContentEntityStorageInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Language\LanguageInterface;
use Drupal\welcome_module\Entity\newInterface;

/**
 * Defines the storage handler class for New entities.
 *
 * This extends the base storage class, adding required special handling for
 * New entities.
 *
 * @ingroup welcome_module
 */
interface newStorageInterface extends ContentEntityStorageInterface {

  /**
   * Gets a list of New revision IDs for a specific New.
   *
   * @param \Drupal\welcome_module\Entity\newInterface $entity
   *   The New entity.
   *
   * @return int[]
   *   New revision IDs (in ascending order).
   */
  public function revisionIds(newInterface $entity);

  /**
   * Gets a list of revision IDs having a given user as New author.
   *
   * @param \Drupal\Core\Session\AccountInterface $account
   *   The user entity.
   *
   * @return int[]
   *   New revision IDs (in ascending order).
   */
  public function userRevisionIds(AccountInterface $account);

  /**
   * Counts the number of revisions in the default language.
   *
   * @param \Drupal\welcome_module\Entity\newInterface $entity
   *   The New entity.
   *
   * @return int
   *   The number of revisions in the default language.
   */
  public function countDefaultLanguageRevisions(newInterface $entity);

  /**
   * Unsets the language for all New with the given language.
   *
   * @param \Drupal\Core\Language\LanguageInterface $language
   *   The language object.
   */
  public function clearRevisionsLanguage(LanguageInterface $language);

}
